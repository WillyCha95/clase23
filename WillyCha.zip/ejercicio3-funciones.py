"""
Hacer un programa que imprima la suma de los números del 1 al 10
"""


lista = range(1,10 + 1)
print("range/rango: ", lista[9])
print("suma: ", sum(lista))

"""
nros = []
while(len(nros) < 10):
    nros.append(len(nros) + 1)
    print("La suma es de: ", sum(nros))
    """