"""
Hacer un programa que imprima los numeros pares del 0 al 10
"""

for i in range(0, 11, 2):
    print(i)