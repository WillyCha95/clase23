"""
Hacer un programa que imprima del 10 al 0 en orden decreciente
"""


for i in range(10, -1, -1):
    print(i)


